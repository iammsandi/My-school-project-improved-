# QUESTION 1
# Student Performance Tracker
import sqlite3 # This module provides a lightweight disk-based database that doesn’t require a separate server process and allows accessing the database using a nonstandard variant of the SQL query language.
import tkinter as tk  # This create a GUI window for the user to interact with the program
from tkinter import messagebox # This is used to display error messages and warnings in the GUI


class Student: # class to represent a student and their result

    def __init__(self, student_name, subject, mark): # Initialize a Student instance
        self.student_name = student_name
        self.subject = subject
        self.mark = mark

    def get_grade(self): # convert the numeric mark to a letter grade based on the following scale:
        if self.mark >= 75:
            return "D"
        elif self.mark >= 60:
            return "M"
        elif self.mark >= 50:
            return "P"
        return "F"
# I use nested if statements to check the mark against the grade thresholds, returning the appropriate letter grade.
    def is_passing(self):

        return self.mark >= 50    # A mark of 50 or above is a pass

    def __str__(self):
        return (f"Student: {self.student_name} | Subject: {self.subject} | "
        f"Mark: {self.mark} | Grade: {self.get_grade()}")


class StudentTrackerApp:
# This class manages the GUI and database interactions for tracking student performance.
    def __init__(self, root):
        self.root = root
        self.setup_database()
        self.build_gui()
        self.load_records()

    def setup_database(self):
        # Create tracker.db and the results table if they do not exist
        connection = None
        try:
            connection = sqlite3.connect("tracker.db") # Connect to the SQLite database file named "tracker.db". If the file does not exist, it will be created.
           # Create the results table if it does not exist. The table has columns for id (primary key), student_name, subject, mark, and grade. 
            connection.execute("""
            CREATE TABLE IF NOT EXISTS results (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                student_name TEXT NOT NULL,
                subject TEXT NOT NULL,
                mark REAL NOT NULL,
                grade TEXT
            )""")
            connection.commit()
        except sqlite3.Error as error:
            messagebox.showerror("Database Error", str(error))
        finally:
            if connection:
                connection.close()

    def build_gui(self):
        # Build all widgets and arrange them with grid
        self.root.title("Student Performance Tracker")

        tk.Label(self.root, text="Student Name:").grid(row=0, column=0, padx=5, pady=5, sticky="e") # This line creates a label widget in the GUI that displays the text "Student Name:". It is positioned in the first column (column 0) of the first row (row 0) of the grid layout. The padx and pady parameters add padding around the label for better spacing, and sticky="e" aligns the label to the east (right) side of its grid cell.
        self.name_entry = tk.Entry(self.root, width=30)
        self.name_entry.grid(row=0, column=1, padx=5, pady=5)

        tk.Label(self.root, text="Subject:").grid(row=1, column=0, padx=5, pady=5, sticky="e") # This line creates a label widget in the GUI that displays the text "Subject:". It is positioned in the first column (column 0) of the second row (row 1) of the grid layout. The padx and pady parameters add padding around the label for better spacing, and sticky="e" aligns the label to the east (right) side of its grid cell.
        self.subject_entry = tk.Entry(self.root, width=30)
        self.subject_entry.grid(row=1, column=1, padx=5, pady=5)

        tk.Label(self.root, text="Mark:").grid(row=2, column=0, padx=5, pady=5, sticky="e") # This line creates a label widget in the GUI that displays the text "Mark:". It is positioned in the first column (column 0) of the third row (row 2) of the grid layout. The padx and pady parameters add padding around the label for better spacing, and sticky="e" aligns the label to the east (right) side of its grid cell.
        self.mark_entry = tk.Entry(self.root, width=30)
        self.mark_entry.grid(row=2, column=1, padx=5, pady=5)

        button_frame = tk.Frame(self.root) # This frame will contain the buttons for adding, deleting, and clearing records
        button_frame.grid(row=3, column=0, columnspan=2, pady=5)
        tk.Button(button_frame, text="Add Record", command=self.add_record).pack(side="left", padx=5)
        tk.Button(button_frame, text="Delete Selected", command=self.delete_record).pack(side="left", padx=5)
        tk.Button(button_frame, text="Clear Fields", command=self.clear_fields).pack(side="left", padx=5)

        list_frame = tk.Frame(self.root) # This frame will contain the listbox and scrollbar for displaying student records
        list_frame.grid(row=4, column=0, columnspan=2, padx=5, pady=5)
        scrollbar = tk.Scrollbar(list_frame, orient="vertical")
        self.record_listbox = tk.Listbox(list_frame, width=80, height=12,
        yscrollcommand=scrollbar.set)
        scrollbar.config(command=self.record_listbox.yview)
        self.record_listbox.pack(side="left")
        scrollbar.pack(side="right", fill="y")

    def add_record(self):
        # Read inputs, build a Student, and insert it with a parameterised query
        try:
            name = self.name_entry.get().strip()
            subject = self.subject_entry.get().strip()
            mark = float(self.mark_entry.get())  # raises ValueError if not numeric
            if not name or not subject:
                messagebox.showwarning("Missing Data", "Name and subject are required.")
                return
            student = Student(name, subject, mark)
            connection = sqlite3.connect("tracker.db")
            connection.execute(
                "INSERT INTO results (student_name, subject, mark, grade) VALUES (?, ?, ?, ?)",
                (student.student_name, student.subject, student.mark, student.get_grade()))
            connection.commit()
            connection.close()
            self.load_records()
        except ValueError:
            messagebox.showerror("Invalid Input", "Mark must be a number.")

    def load_records(self): # Refresh the listbox with all records ordered by name
        # Refresh the listbox with all records ordered by name
        self.record_listbox.delete(0, tk.END)
        connection = None
        try:
            connection = sqlite3.connect("tracker.db")
            rows = connection.execute(
                "SELECT student_name, subject, mark FROM results ORDER BY student_name ASC"
            ).fetchall()
            for name, subject, mark in rows:
                self.record_listbox.insert(tk.END, str(Student(name, subject, mark)))
        except sqlite3.Error as error:
            messagebox.showerror("Database Error", str(error))
        finally:
            if connection:
                connection.close()

    def delete_record(self):
        # Delete the selected record, identified by name and subject
        selection = self.record_listbox.curselection()
        if not selection:
            messagebox.showwarning("No Selection", "Please select a record to delete.")
            return
        selected_text = self.record_listbox.get(selection[0])
        parts = selected_text.split(" | ")
        name = parts[0].replace("Student: ", "")
        subject = parts[1].replace("Subject: ", "")
        connection = None
        try:
            connection = sqlite3.connect("tracker.db")
            connection.execute(
                "DELETE FROM results WHERE student_name = ? AND subject = ?", (name, subject))
            connection.commit()
            self.load_records()
        except sqlite3.Error as error:
            messagebox.showerror("Database Error", str(error))
        finally:
            if connection:
                connection.close()

    def clear_fields(self): # Empty all entries and return focus to the name field
        # Empty all entries and return focus to the name field
        self.name_entry.delete(0, tk.END)
        self.subject_entry.delete(0, tk.END)
        self.mark_entry.delete(0, tk.END)
        self.name_entry.focus()


if __name__ == "__main__": # This is the main entry point of the program. It creates the Tkinter root window and starts the application.
    root = tk.Tk() # This creates the main application window using Tkinter, which will serve as the container for all GUI elements of the Student Performance Tracker application.
    app = StudentTrackerApp(root) # This creates an instance of the StudentTrackerApp class, passing the root window as an argument. The application will manage the GUI and database interactions for tracking student performance.
    root.mainloop() # This starts the Tkinter event loop, allowing the GUI to respond to user interactions until the window is closed.