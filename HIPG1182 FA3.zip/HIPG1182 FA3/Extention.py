# Extension for Student Performance Tracker
import sqlite3 # This module provides a lightweight disk-based database that doesn’t require a separate server process and allows accessing the database using a nonstandard variant of the SQL query language.
import pandas as pd # This library is used for data manipulation and analysis. It provides data structures and functions needed to manipulate structured data seamlessly.
import matplotlib.pyplot as plt # This library is used for creating static, animated, and interactive visualizations in Python. It provides a MATLAB-like interface for plotting graphs and charts.


def load_data(): # validate the database and load data into a DataFrame
    # Read all rows from the results table into a DataFrame
    connection = None
    try: # the try block attempts to connect to the SQLite database and fetch all records from the results table. If the table does not exist or there is an error in reading the database, it will raise an exception.
        connection = sqlite3.connect("tracker.db")
        rows = connection.execute("SELECT id, student_name, subject, mark, grade FROM results").fetchall()
    except sqlite3.Error: # If an error occurs during the database connection or query execution, it will print an error message indicating that the results table does not exist or the database could not be read.
        print("The results table does not exist or the database could not be read.")
        return None
    finally: # The finally block ensures that the database connection is closed after the operations are completed, regardless of whether an exception was raised or not. If the connection was established, it will be closed to free up resources. If there are no rows fetched from the results table, it will print a message indicating that the table is empty and return None. If there are rows, it will convert them into a pandas DataFrame with appropriate column names and return it for further analysis.
        if connection:
            connection.close()
            if not rows:
                print("The results table is empty.")
                return None
            return pd.DataFrame(rows, columns=["id", "student_name", "subject", "mark", "grade"]) # Return the DataFrame


def show_summary(df): # Display summary statistics for the mark column
    # Print descriptive statistics for the mark column
    marks = df["mark"]
    print("\n--- Mark Summary ---")
    print(f"Count:   {marks.count()}")
    print(f"Mean:    {round(marks.mean(), 2)}")
    print(f"Minimum: {round(marks.min(), 2)}")
    print(f"Maximum: {round(marks.max(), 2)}")
    print(f"Std Dev: {round(marks.std(), 2)}")


def average_mark_by_subject(df): # Calculate and display average marks by subject
    # Group by subject, print the averages, then draw a bar chart
    averages = df.groupby("subject")["mark"].mean().round(1)
    print("\n--- Average Mark by Subject ---")
    print(f"{'Subject':<25}{'Average Mark':>12}")
    for subject, average in averages.items():
        print(f"{subject:<25}{average:>12}")

        plt.figure() # Create a new figure for the bar chart
        bars = plt.bar(averages.index, averages.values)
        plt.title("Average Mark by Subject")
        plt.xlabel("Subject")
        plt.ylabel("Average Mark")
        plt.ylim(0, 100)
        for bar, value in zip(bars, averages.values):
            plt.text(bar.get_x() + bar.get_width() / 2, value + 1, str(value), ha="center")
            plt.show()


def grade_distribution(df): # Calculate and display the distribution of grades
    # Count each grade category, print the counts, then draw a pie chart
    counts = df["grade"].value_counts().reindex(["D", "M", "P", "F"], fill_value=0)
    print("\n--- Grade Distribution ---")
    for grade, count in counts.items():
        print(f"{grade}: {count}") # Print the count of each grade category in the terminal.

        non_zero = counts[counts > 0]  # avoid empty slices in the pie
        plt.figure()
        plt.pie(non_zero.values, labels=non_zero.index, autopct="%1.1f%%")
        plt.title("Grade Distribution")
        plt.show() # Display the pie chart for grade distribution


if __name__ == "__main__": # This block checks if the script is being run directly (not imported as a module). If it is, it will execute the code inside this block. It calls the load_data function to retrieve the student performance data from the database. If data is successfully loaded and is not empty, it will call the show_summary, average_mark_by_subject, and grade_distribution functions to display the summary statistics, average marks by subject, and grade distribution respectively. If no data is available, it will print a message indicating that there is no data to analyze.
    data = load_data()
    if data is not None and not data.empty:
        show_summary(data) # SOW THE summary statistics for the mark column IN THE Terminal. This includes the count, mean, minimum, maximum, and standard deviation of the marks.  
        average_mark_by_subject(data)
        grade_distribution(data)
    else:
        print("No data is available to analyse.") # Print a message if no data is available for analysis.